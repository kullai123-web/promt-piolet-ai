"use client"

import { useEffect } from "react"

interface TitleUpdaterProps {
  title: string
  suffix?: string
}

export function TitleUpdater({ title, suffix = "PromptPilot" }: TitleUpdaterProps) {
  useEffect(() => {
    // Update the document title
    document.title = suffix ? `${title} | ${suffix}` : title

    // Cleanup function to reset title when component unmounts
    return () => {
      document.title = "PromptPilot"
    }
  }, [title, suffix])

  // This component doesn't render anything
  return null
}
