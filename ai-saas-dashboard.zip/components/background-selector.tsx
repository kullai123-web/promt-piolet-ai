"use client"

import { useState, useEffect } from "react"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const themes = [
  { name: "Purple", value: "var(--gradient-1)", color: "bg-purple-400 dark:bg-purple-700" },
  { name: "Blue", value: "var(--gradient-2)", color: "bg-blue-400 dark:bg-blue-700" },
  { name: "Teal", value: "var(--gradient-3)", color: "bg-teal-400 dark:bg-teal-700" },
  { name: "Green", value: "var(--gradient-4)", color: "bg-green-400 dark:bg-green-700" },
]

export function BackgroundSelector() {
  const [activeTheme, setActiveTheme] = useState(themes[0].name)

  const changeTheme = (theme: (typeof themes)[0]) => {
    document.documentElement.style.setProperty("--gradient-active", theme.value)
    setActiveTheme(theme.name)
    // Save preference to localStorage
    localStorage.setItem("bgTheme", theme.name)
  }

  // Load saved preference on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("bgTheme")
    if (savedTheme) {
      const theme = themes.find((t) => t.name === savedTheme)
      if (theme) {
        document.documentElement.style.setProperty("--gradient-active", theme.value)
        setActiveTheme(theme.name)
      }
    }
  }, [])

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="rounded-full">
          <div className={`h-4 w-4 rounded-full ${themes.find((t) => t.name === activeTheme)?.color}`} />
          <span className="sr-only">Change background</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {themes.map((theme) => (
          <DropdownMenuItem key={theme.name} onClick={() => changeTheme(theme)} className="flex items-center gap-2">
            <div className={`h-4 w-4 rounded-full ${theme.color}`} />
            <span>{theme.name}</span>
            {activeTheme === theme.name && <Check className="ml-auto h-4 w-4" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
