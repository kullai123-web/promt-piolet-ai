import { Check, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { TitleUpdater } from "@/components/title-updater"

export default function SubscriptionPage() {
  return (
    <div className="flex flex-col gap-4">
      <TitleUpdater title="Subscription" />
      <h1 className="text-3xl font-bold">Subscription</h1>
      <p className="text-muted-foreground">Choose the plan that's right for you</p>

      <div className="grid gap-6 pt-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Free Plan</CardTitle>
            <CardDescription>Basic features for personal use</CardDescription>
            <div className="mt-4 text-4xl font-bold">$0</div>
            <p className="text-sm text-muted-foreground">per month</p>
          </CardHeader>
          <CardContent className="flex-1">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>5 AI conversations per day</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Basic AI model access</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Chat history for 7 days</span>
              </li>
              <li className="flex items-center gap-2">
                <X className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Advanced AI models</span>
              </li>
              <li className="flex items-center gap-2">
                <X className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Priority support</span>
              </li>
              <li className="flex items-center gap-2">
                <X className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">API access</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Current Plan
            </Button>
          </CardFooter>
        </Card>

        <Card className="flex flex-col border-primary">
          <CardHeader>
            <div className="rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground w-fit">
              Popular
            </div>
            <CardTitle className="mt-4">Pro Plan</CardTitle>
            <CardDescription>Advanced features for power users</CardDescription>
            <div className="mt-4 text-4xl font-bold">$19</div>
            <p className="text-sm text-muted-foreground">per month</p>
          </CardHeader>
          <CardContent className="flex-1">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Unlimited AI conversations</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Access to advanced AI models</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Unlimited chat history</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Priority support</span>
              </li>
              <li className="flex items-center gap-2">
                <X className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">API access</span>
              </li>
              <li className="flex items-center gap-2">
                <X className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Custom AI fine-tuning</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Upgrade to Pro</Button>
          </CardFooter>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Enterprise Plan</CardTitle>
            <CardDescription>Custom solutions for businesses</CardDescription>
            <div className="mt-4 text-4xl font-bold">$99</div>
            <p className="text-sm text-muted-foreground">per month</p>
          </CardHeader>
          <CardContent className="flex-1">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Everything in Pro plan</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>API access with higher rate limits</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Custom AI model fine-tuning</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Dedicated account manager</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>SSO and team management</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Custom integrations</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Contact Sales
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Subscription Details</CardTitle>
            <CardDescription>Your current subscription information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <p className="text-sm font-medium">Current Plan</p>
                <p className="text-sm text-muted-foreground">Free Plan</p>
              </div>
              <div>
                <p className="text-sm font-medium">Billing Cycle</p>
                <p className="text-sm text-muted-foreground">Monthly</p>
              </div>
              <div>
                <p className="text-sm font-medium">Next Billing Date</p>
                <p className="text-sm text-muted-foreground">N/A</p>
              </div>
              <div>
                <p className="text-sm font-medium">Payment Method</p>
                <p className="text-sm text-muted-foreground">None</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-start gap-2 sm:flex-row sm:justify-between">
            <Button variant="outline">Update Payment Method</Button>
            <Button variant="outline" className="text-destructive hover:bg-destructive/10">
              Cancel Subscription
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
